<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successful</title>
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Registration Successful</h2>
            <p>Thank you for registering. Your information has been successfully saved.</p>
            <a href="main.php" class="btn">Go Back</a>
        </div>
    </div>
</body>
</html>